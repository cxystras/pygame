str = 'hello'

print(str)
print(type(str))